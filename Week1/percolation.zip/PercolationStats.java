import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

/**
 * Created by mac on 06/10/2017.
 */
public class PercolationStats {
    private int trials;
    private double mean;
    private double stddev;
    private double[] x;
    // perform trials independent experiments on an n-by-n grid
    public PercolationStats(int n, int trials){
        if(n<=0||trials<=0) throw new IllegalArgumentException();
        this.trials = trials;
        x = new double[trials];
        for(int i =0;i<trials;i++){
            Percolation percolation = new Percolation(n);
            while (!percolation.percolates()){
                int row = StdRandom.uniform(1,n+1);
                int col = StdRandom.uniform(1,n+1);
                percolation.open(row,col);
            }

            x[i]=percolation.numberOfOpenSites()/(double)(n*n);
        }

    }
    // sample mean of percolation threshold
    public double mean(){
        mean = StdStats.mean(x);
        return mean;
    }
    // sample standard deviation of percolation threshold
    public double stddev(){
        stddev = StdStats.stddev(x);
        return stddev;
    }
    // low  endpoint of 95% confidence interval
    public double confidenceLo(){
        return mean-(1.96*stddev/Math.sqrt(trials));

    }
    // high endpoint of 95% confidence interval
    public double confidenceHi(){
        return mean+(1.96*stddev/Math.sqrt(trials));
    }

    public static void main(String[] args){
        final int n = Integer.valueOf(args[0]);
        final int trials = Integer.valueOf(args[1]);
        PercolationStats percolationSats = new PercolationStats(n,trials);
        System.out.println("mean="+ percolationSats.mean());
        System.out.println("stddev="+ percolationSats.stddev());
        System.out.println("95% confidence interval = ["
                + percolationSats.confidenceLo()
                +","+ percolationSats.confidenceHi()
                +"]");
    }
}
